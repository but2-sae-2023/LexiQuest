package com.example.lexiquest;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Button;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {

    private static final String PHP_SCRIPT_URL = "https://perso-etudiant.u-pem.fr/~rabah.cherak/LexiQuest-bis/appli.php";

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private WebView webView;

    private Button buttonDeco;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Liaison des vues
        webView = findViewById(R.id.webView);
        buttonDeco = findViewById(R.id.buttonDeco);
        buttonDeco.setVisibility(View.GONE);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        // Ajouter un écouteur de clic sur le bouton de connexion
        buttonLogin.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onClick(View v) {
                // Récupérer le nom d'utilisateur et le mot de passe saisis par l'utilisateur
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // Créer les données à envoyer
                String postData = null;
                try {
                    postData = "user=" + URLEncoder.encode(username, "UTF-8") + "&pwd=" + URLEncoder.encode(password, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
                editTextUsername.setVisibility(View.GONE);
                editTextPassword.setVisibility(View.GONE);
                buttonLogin.setVisibility(View.GONE);

                // Charger l'URL de la page PHP dans le WebView avec les données de connexion
                CookieManager cookieManager = CookieManager.getInstance();
                cookieManager.setAcceptThirdPartyCookies(webView, true);
                webView.setVisibility(View.VISIBLE);
                webView.setWebViewClient(new WebViewClient());
                webView.getSettings().setJavaScriptEnabled(true);
                webView.getSettings().setDomStorageEnabled(true);
                webView.loadUrl(PHP_SCRIPT_URL + "?" + postData) ;
            }
        });
    }
}
